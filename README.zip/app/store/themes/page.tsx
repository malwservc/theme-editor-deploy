'use client'

import { useState } from 'react'

const themes = [
  { id: 'default', name: 'Tema Padrão', updatedAt: '2025-04-08' },
  { id: 'black-friday', name: 'Black Friday', updatedAt: '2025-03-01' },
]

export default function ThemesPage() {
  const [selectedTheme, setSelectedTheme] = useState<any>(null)

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Temas Disponíveis</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {themes.map((theme) => (
          <div
            key={theme.id}
            className="bg-white rounded-xl border shadow-sm p-6 flex flex-col justify-between"
          >
            <div>
              <h2 className="text-lg font-semibold">{theme.name}</h2>
              <p className="text-sm text-gray-500 mt-1">Atualizado em {theme.updatedAt}</p>
            </div>

            <div className="mt-4">
              <button
                onClick={() => setSelectedTheme(theme)}
                className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition"
              >
                Editar
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedTheme && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white w-full max-w-lg p-6 rounded-xl shadow-xl relative">
            <button
              className="absolute top-3 right-4 text-gray-400 hover:text-gray-600 text-xl"
              onClick={() => setSelectedTheme(null)}
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-4">Editar Tema: {selectedTheme.name}</h2>

            {/* Conteúdo do modal: edição futura de arquivos etc */}
            <p className="text-gray-700 text-sm">Aqui você poderá editar arquivos do tema, alterar o nome, etc.</p>
          </div>
        </div>
      )}
    </div>
  )
}
